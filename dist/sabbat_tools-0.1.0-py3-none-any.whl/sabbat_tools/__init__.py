__all__ = ["loganalyce", "fileinspect"]
__version__ = "0.1.0"

