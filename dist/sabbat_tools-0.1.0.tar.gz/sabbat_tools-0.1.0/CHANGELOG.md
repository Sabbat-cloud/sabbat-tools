# Changelog

## 0.1.0
- Initial release as `sabbat-tools` (migrado desde repos previos).
- Incluye `sabbat-loganalyce` (preaviso early de logs grandes) y `sabbat-fileinspect` (i18n + JSON).

